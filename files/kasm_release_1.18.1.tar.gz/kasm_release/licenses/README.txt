1.0 Definitions
--------------
1.1 Company - Kasm Technologies LLC
1.2 Kasm - The containerized desktop or application accessed by a client through a browser
1.3 Base Kasm - All Kasms are derived from the Base Kasm docker image
1.4 Kasm Server - The server side application that serves the Kasms to the users


This directory contains all licenses for software distributed with or installed
by the Kasm Server software. The base Kasm image contains all licenses that pertain to
the Kasm. Custom Kasms must derive from the base Kasm and include all license from
the base image.